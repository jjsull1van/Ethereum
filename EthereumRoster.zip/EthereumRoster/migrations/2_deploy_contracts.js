var StudentList = artifacts.require("./StudentList.sol");

module.exports = function(deployer) {
  deployer.deploy(StudentList);
};
